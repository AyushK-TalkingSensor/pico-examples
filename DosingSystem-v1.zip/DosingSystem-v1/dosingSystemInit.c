#include "dosingSystemCommon.h"

void dosingSystemInit(void){

printf("Hello world");
}