#ifndef _DOSING_SYSTEM_COMMON_H_
    #define _DOSING_SYSTEM_COMMON_H_

#include <stdio.h>
#include <stdint.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"

typedef enum {State_idel=0,state_Processing,State_handler,state_sleep}StatesOfMcu;

extern uint32_t dosingSystemTestApp(void);
extern void dosingSystemInit(void);

#endif /* End of __DOSING_SYSTEM_COMMON_H__ */
