#include "dosingSystemCommon.h"

uint32_t dosingSystemTestApp(void){

    while(true){
        dosingSystemInit();
    
    }
}