#include "dosingSystemCommon.h"



int main(void){
printf(Ayush);
printf(State_idel);
dosingSystemTestApp();
return 0;

}